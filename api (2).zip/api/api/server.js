const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
const port = 3000;
const host = "192.168.1.8";

app.use(cors());
app.use(express.json())
app.use(express.urlencoded({ extended: true }));
// Konfigurasi koneksi database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'apk'
});

// Connect ke database
db.connect(err => {
  if (err) {
    throw err;
  }
  console.log('MySQL Connected...');
});

app.post('/api/register', async (req, res) => {
    try {
      const { name, username, password } = req.body;
      const sql = 'INSERT INTO users (name, username, password) VALUES (?, ?, ?)';
      db.query(sql, [name, username, password], (err, result) => {
        res.status(200).json({
          status: true,
          name,
          username,
          password,
        });
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error adding user',
        error: error.message
      });
    }
  });

// LOGIN: Verifikasi pengguna
app.post('/api/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';
      db.query(sql, [username, password], (err, result) => {
        if (err) {
          throw err;
        }
        if (result.length > 0) {
          res.status(200).json({
            status: true,
            message: 'Login successful',
            user: result[0]
          });
        } else {
          res.status(401).json({
            status: false,
            message: 'Invalid username or password'
          });
        }
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error during login',
        error: error.message
      });
    }
  });

  app.post('/api/addsakit', async (req, res) => {
    try {
      const { penyakit, obat } = req.body;
      const sql = 'INSERT INTO sakit (penyakit, obat) VALUES (?, ?)';
      db.query(sql, [penyakit, obat], (err, result) => {
        res.status(200).json({
          status: true,
          obat,
          penyakit
        });
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error adding user',
        error: error.message
      });
    }
  });
  app.get('/api/getsakit/:penyakit', async (req, res) => {
    try {
      const { penyakit } = req.params;
      const sql = 'SELECT * FROM sakit WHERE penyakit = ?';
      db.query(sql, [[penyakit]], (err, result) => {
        if (err) {
          return res.status(500).json({
            status: false,
            message: 'Error retrieving sakit',
            error: err.message
          });
        }
        if (result.length > 0) {
          const sakit = result[0];
          res.status(200).json({
            status: true,
            data: sakit
          });
        } else {
          res.status(404).json({
            status: false,
            message: 'sakit not found'
          });
        }
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error retrieving sakit',
        error: error.message
      });
    }
  });
  app.get('/api/getsakit', async (req, res) => {
    try {
      // const { penyakit } = req.params;
      const sql = 'SELECT * FROM sakit';
      db.query(sql, (err, result) => {
        if (err) {
          return res.status(500).json({
            status: false,
            message: 'Error retrieving sakit',
            error: err.message
          });
        }
        if (result.length > 0) {
          const sakit = result;
          res.status(200).json({
            status: true,
            data: sakit
          });
        } else {
          res.status(404).json({
            status: false,
            message: 'sakit not found'
          });
        }
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error retrieving sakit',
        error: error.message
      });
    }
  });
  
  app.get('/api/deletesakit/:penyakit', async (req, res) => {
    try {
      const { penyakit } = req.params;
      const sql = 'DELETE FROM sakit WHERE penyakit = ?';
      db.query(sql, [penyakit], (err, result) => {
        if (err) {
          return res.status(500).json({
            status: false,
            message: 'Error deleting sakit',
            error: err.message
          });
        }
        if (result.affectedRows > 0) {
          res.status(200).json({
            status: true,
            message: 'sakit deleted successfully'
          });
        } else {
          res.status(404).json({
            status: false,
            message: 'sakit not found'
          });
        }
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error deleting sakit',
        error: error.message
      });
    }
  });
  

app.listen(port, host, () => {
  console.log(`Server started on port ${host}:${port}`);
});
